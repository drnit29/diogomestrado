import pandas as pd
import unidecode

def calc_share(df, col_if, col_carteira, col_data):
    df[col_data] = pd.to_datetime(df[col_data])

    soma_carteira_mes = df.groupby(col_data)[col_carteira].sum().reset_index()
    soma_carteira_mes = soma_carteira_mes.rename(
        columns={col_carteira: f"TM{col_carteira}"}
    )

    df = df.merge(soma_carteira_mes, on=col_data)

    df[f"%{col_carteira}"] = 100*(df[col_carteira] / df[f"TM{col_carteira}"])

    resultado = df[[col_data, col_if, f"%{col_carteira}"]].copy()
    return resultado

def top_n(df, col_if, col_carteira, col_data, n):
    df_share = calc_share(df, col_if, col_carteira, col_data)

    df_share_sorted = df_share.sort_values(
        by=[col_data, f"%{col_carteira}"], ascending=[True, False]
    ).copy()

    top_n_df = df_share_sorted.groupby(col_data).head(n).reset_index(drop=True)
    return top_n_df

def data_to_ano(df, col_data):
    df[col_data] = pd.to_datetime(df[col_data])
    df = df[df[col_data].dt.month == 12]
    df[col_data] = pd.to_datetime(df[col_data], format="%Y-%m-%d").dt.strftime("%Y")
    return df

def hhi_calc(df, col_if, col_carteira, col_data):
    df[col_data] = pd.to_datetime(df[col_data])

    soma_carteira_mes = df.groupby(col_data)[col_carteira].sum().reset_index()
    soma_carteira_mes = soma_carteira_mes.rename(
        columns={col_carteira: f"TM{col_carteira}"}
    )

    df = df.merge(soma_carteira_mes, on=col_data)

    df[f"%{col_carteira}"] = df[col_carteira] / df[f"TM{col_carteira}"]

    df[f"%{col_carteira}^2"] = df[f"%{col_carteira}"] ** 2

    df_hhi = df.groupby(col_data)[f"%{col_carteira}^2"].sum().reset_index()

    df_hhi.rename(columns={f"%{col_carteira}^2": "HHI"}, 
)

    return df_hhi

def ajustarcolunas(df):
    df.columns = df.columns.str.lower().str.strip().str.replace("(", "").str.replace(")", "").str.replace(" ", "_").to_series().apply(unidecode.unidecode)
    print('Colunas do ajustadas com sucesso!')

def criarmapa(df, col_a, col_b):
    df_unique = df[[col_a, col_b]].drop_duplicates(subset=[col_a]).reset_index(drop=True)
    a = list(df_unique[col_a])
    b = list(df_unique[col_b])
    mapa = dict(zip(a, b))
    print(f"Conciodo mapa de {a} e {b}")
    return mapa

