import pandas as pd
import unidecode
from PIL import Image

def calc_share(df, col_if, col_carteira, col_data):
    df[col_data] = pd.to_datetime(df[col_data])

    soma_carteira_mes = df.groupby(col_data)[col_carteira].sum().reset_index()
    soma_carteira_mes = soma_carteira_mes.rename(
        columns={col_carteira: f"TM{col_carteira}"}
    )

    df = df.merge(soma_carteira_mes, on=col_data)

    df[f"%{col_carteira}"] = 100*(df[col_carteira] / df[f"TM{col_carteira}"])

    resultado = df[[col_data, col_if, f"%{col_carteira}"]].copy()
    resultado = resultado.sort_values(by=[col_data, f"%{col_carteira}"], ascending=[False, True])
    resultado[col_data] = pd.to_datetime(resultado[col_data])
    return resultado

def top_n(df, col_if, col_carteira, col_data, n):

    df_share = calc_share(df, col_if, col_carteira, col_data)

    df_share_sorted = df_share.sort_values(
        by=[col_data, f"%{col_carteira}"], ascending=[True, False]
    ).copy()

    top_n_df = df_share_sorted.groupby(col_data).head(n).reset_index(drop=True)
    return top_n_df

def data_para_ano(df, col_data):
    df[col_data] = pd.to_datetime(df[col_data])
    df = df[df[col_data].dt.month == 12]
    df[col_data] = pd.to_datetime(df[col_data], format="%Y-%m-%d").dt.strftime("%Y")
    return df

def hhi_calc(df, col_if, col_carteira, col_data):
    df[col_data] = pd.to_datetime(df[col_data])

    soma_carteira_mes = df.groupby(col_data)[col_carteira].sum().reset_index()
    soma_carteira_mes = soma_carteira_mes.rename(
        columns={col_carteira: f"TM{col_carteira}"}
    )

    df = df.merge(soma_carteira_mes, on=col_data)

    df[f"%{col_carteira}"] = df[col_carteira] / df[f"TM{col_carteira}"]

    df[f"%{col_carteira}^2"] = df[f"%{col_carteira}"] ** 2

    df_hhi = df.groupby(col_data)[f"%{col_carteira}^2"].sum().reset_index()

    df_hhi.rename(columns={f"%{col_carteira}^2": "HHI"}, inplace=True)

    resultado = df_hhi
    return resultado

def ajustarcolunas(df):
    df.columns = df.columns.str.lower().str.strip().str.replace("(", "").str.replace(")", "").str.replace(" ", "_").to_series().apply(unidecode.unidecode)
    print('Colunas do ajustadas com sucesso!')
    return df.columns
    
    
def criarmapa(df, a, b):
    a1 = df[[a,b]].drop_duplicates(subset=[a]).reset_index(drop=True)
    a1 = list(df[a])
    b1 = list(df[b])
    mapa = dict(zip(a1, b1))
    print(f"Concluido mapa de {a} e {b}")
    return mapa
    
def mergedata(df1, df2, datacol):
    dt1 = df1.copy()
    dt2 = df2.copy()
    dt1[datacol] = pd.to_datetime(dt1[datacol])
    dt2[datacol] = pd.to_datetime(dt2[datacol])
    dt3 = pd.merge(dt1, dt2, on=datacol, how='left')
    print("Merge concluido com sucesso!")
    return dt3
    
def get_image_size(image_path):
    # Abre a imagem
    with Image.open(image_path) as img:
        # Obtém o tamanho da imagem
        width, height = img.size
        return width, height
        
def ajustartamanho(a, image_path):
    width, height = get_image_size(image_path)
    if width != 1890:
        a = a * 1890 / width
    else:
        print(f"Tamanho da imagem está correto.\nO valor de a é {a}")