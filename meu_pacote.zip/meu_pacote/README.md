# Meu Pacote

Este pacote inclui diversas funções para manipulação e análise de dados em pandas.

## Funções incluídas

- `calc_share`
- `top_n`
- `data_to_ano`
- `hhi_calc`
- `ajustarcolunas`
- `criarmapa`
